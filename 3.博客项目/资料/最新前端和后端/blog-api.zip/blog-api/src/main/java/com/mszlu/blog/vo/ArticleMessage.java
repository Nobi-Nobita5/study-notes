package com.mszlu.blog.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author B站：码神之路
 */
@Data
public class ArticleMessage implements Serializable {

    private Long articleId;

}
