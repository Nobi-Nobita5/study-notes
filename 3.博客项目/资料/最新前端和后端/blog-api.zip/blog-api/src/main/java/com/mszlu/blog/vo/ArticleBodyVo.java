package com.mszlu.blog.vo;

import lombok.Data;

@Data
public class ArticleBodyVo {

    private String content;
}
