package com.mszlu.blog.vo;

import lombok.Data;

@Data
public class TagVo {

    private String id;

    private String tagName;

    private String avatar;
}
